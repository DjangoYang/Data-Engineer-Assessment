

import json
import time
from kafkaEndpointConf import HOST, PORT
from flask import Flask, request, render_template, Response
from kafka import KafkaConsumer, KafkaProducer

TOPIC_NAME = "msft-data"
TOPIC_output_NAME = "msft-output"
KAFKA_SERVER = HOST + ":" + str(PORT)
CERTS_FOLDER = "certs"
CONSUMER_GROUP = "msft-consumers"
CONSUMER_GROUP_output = "msft-consumers"
CONSUMER_GROUP_CALC = "msft-calculators"



producer = KafkaProducer(
    bootstrap_servers=KAFKA_SERVER,
    security_protocol="SSL",
    ssl_cafile=CERTS_FOLDER + "/ca.pem",
    ssl_certfile=CERTS_FOLDER + "/service.cert",
    ssl_keyfile=CERTS_FOLDER + "/service.key",
    value_serializer=lambda v: json.dumps(v).encode('ascii'),
    key_serializer=lambda v: json.dumps(v).encode('ascii')
)

app = Flask(__name__, template_folder='templates')




@app.route('/', methods=['GET', 'POST'])
def index():

    if request.method == 'POST':
        producer.send(
            TOPIC_NAME,
            key={"caller": request.form.get("caller")},
            value={
                "caller": request.form.get("caller"),
                "msft": request.form.get("msft"),
                "address": request.form.get("address"),
                "timestamp": int(time.time())
            }
        )

        producer.flush()
    elif request.method == 'GET':
        return render_template('index.html', form=request.form)

    return render_template("index.html")

# is a function allowing the streaming of results back to the source page


def stream_template(template_name, **context):
    """Enabling streaming back results to app"""
    app.update_template_context(context)
    template = app.jinja_env.get_template(template_name)
    streaming = template.stream(context)
    return streaming

# msft-makers reads from the msft-data topic
# and allows msftioli to click on the msfts they already made.
# Once the click is pushed, the /msft-ready endpoint is called
# passing the order ID


@app.route('/msft-makers')
def consume():
    """Returning msft data"""
    consumer = KafkaConsumer(
        client_id="client1",
        group_id=CONSUMER_GROUP,
        bootstrap_servers=KAFKA_SERVER,
        security_protocol="SSL",
        ssl_cafile=CERTS_FOLDER+"/ca.pem",
        ssl_certfile=CERTS_FOLDER+"/service.cert",
        ssl_keyfile=CERTS_FOLDER+"/service.key",
        value_deserializer=lambda v: json.loads(v.decode('ascii')),
        key_deserializer=lambda v: json.loads(v.decode('ascii')),
        max_poll_records=10,
        auto_offset_reset='earliest',
        session_timeout_ms=6000,
        heartbeat_interval_ms=3000
    )
    consumer.subscribe(topics=[TOPIC_NAME])

    def consume_msg():
        for message in consumer:
            print(message.value)
            yield [
                message.value["timestamp"],
                message.value["caller"],
                message.value["msft"],
                message.value["address"],
                1]

    return Response(stream_template('msft-makers.html', data=consume_msg()))

# /msft-ready/<id> receives the info about a
# msft-order being in ready state from msftioli
# and adds it into the msft-output topic


@app.route('/msft-ready/<my_id>', methods=['POST'])
def msft_ready(my_id=None):
    """Endpoint to pass ready msfts"""
    print(my_id)
    producer.send(
        TOPIC_output_NAME,
        key={"timestamp": my_id},
        value=request.json
    )
    producer.flush()
    return "OK"

# /msft-calc simulates the billing person,
# reading from the msft-data topic
# but with a different consumer group,
# therefore receiving a copy of each message
# without conflicting with msft-makers


@app.route('/msft-calc')
def consume_calc():
    """Returning home page for msft calculators"""
    consumer_calc = KafkaConsumer(
        client_id="client3",
        group_id=CONSUMER_GROUP_CALC,
        bootstrap_servers=KAFKA_SERVER,
        security_protocol="SSL",
        ssl_cafile=CERTS_FOLDER+"/ca.pem",
        ssl_certfile=CERTS_FOLDER+"/service.cert",
        ssl_keyfile=CERTS_FOLDER+"/service.key",
        value_deserializer=lambda v: json.loads(v.decode('ascii')),
        key_deserializer=lambda v: json.loads(v.decode('ascii')),
        max_poll_records=10,
        auto_offset_reset='earliest',
        session_timeout_ms=6000,
        heartbeat_interval_ms=3000
    )
    consumer_calc.subscribe(topics=[TOPIC_NAME])

    def consume_msg():
        for message in consumer_calc:
            print(message.value)
            yield [
                message.value["timestamp"],
                message.value["caller"],
                message.value["msft"],
                message.value["address"],
                1]

    return Response(
        stream_template('msft-calculators.html', data=consume_msg()))

# /msft-output reads from the topic msft-output
# and display the results of msft ready for output


@app.route('/msft-output')
def consume_output():
    """Returning home page for msft output"""
    consumer_output = KafkaConsumer(
        client_id="clientoutput",
        group_id=CONSUMER_GROUP_output,
        bootstrap_servers=KAFKA_SERVER,
        security_protocol="SSL",
        ssl_cafile=CERTS_FOLDER+"/ca.pem",
        ssl_certfile=CERTS_FOLDER+"/service.cert",
        ssl_keyfile=CERTS_FOLDER+"/service.key",
        value_deserializer=lambda v: json.loads(v.decode('ascii')),
        key_deserializer=lambda v: json.loads(v.decode('ascii')),
        max_poll_records=10,
        auto_offset_reset='earliest',
        session_timeout_ms=6000,
        heartbeat_interval_ms=3000
    )
    consumer_output.subscribe(topics=[TOPIC_output_NAME])

    def consume_msg_output():
        for message in consumer_output:
            print(message.value)
            yield [
                message.key["timestamp"],
                message.value["caller"],
                message.value["address"]
            ]

    return Response(
        stream_template('msft-output.html', data=consume_msg_output()))


if __name__ == "__main__":
    app.run(debug=True, port=5000)

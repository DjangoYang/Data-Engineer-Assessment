# /bin/bash

. conf/env.conf
 

avn --auth-token $TOKEN                     \
    service terminate demo-flask-ka --force    \
    --project $PROJECT_NAME

avn --auth-token $TOKEN                          \
    service terminate demo-flask-op --force    \
    --project $PROJECT_NAME